package com.loan.loanapplication.repositories;

import org.springframework.data.jpa.repository.JpaRepository;


import com.loan.loanapplication.model.CreditCheck;

public interface CreditCheckRepository extends JpaRepository<CreditCheck, Integer> {
	


}
