//package com.loan.loanapplication.repositories;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.loan.loanapplication.model.Disbursement;
//
//public interface DisbursementRepository extends JpaRepository<Disbursement, String> {
//
//}
