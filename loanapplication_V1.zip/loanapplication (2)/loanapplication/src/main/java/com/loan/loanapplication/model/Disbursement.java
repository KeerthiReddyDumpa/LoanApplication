//package com.loan.loanapplication.model;
//
//
//
//import java.util.UUID;
//
//import jakarta.persistence.Entity;
//import jakarta.persistence.Id;
//import jakarta.persistence.JoinColumn;
//import jakarta.persistence.ManyToOne;
//
//@Entity
//public class Disbursement {
//
//    @Id
//    private String id;
//
//    @ManyToOne
//    @JoinColumn(name = "application_id")
//    private LoanApplication loanApplication;
//
//    private double amount;
//    private long disbursedAt;
//    private String status;
//
//    public Disbursement() {
//        this.id = UUID.randomUUID().toString();
//    }
//
//	public String getId() {
//		return id;
//	}
//
//	public void setId(String id) {
//		this.id = id;
//	}
//
//	public LoanApplication getLoanApplication() {
//		return loanApplication;
//	}
//
//	public void setLoanApplication(LoanApplication loanApplication) {
//		this.loanApplication = loanApplication;
//	}
//
//	public double getAmount() {
//		return amount;
//	}
//
//	public void setAmount(double amount) {
//		this.amount = amount;
//	}
//
//	public long getDisbursedAt() {
//		return disbursedAt;
//	}
//
//	public void setDisbursedAt(long disbursedAt) {
//		this.disbursedAt = disbursedAt;
//	}
//
//	public String getStatus() {
//		return status;
//	}
//
//	public void setStatus(String status) {
//		this.status = status;
//	}
//
//	@Override
//	public String toString() {
//		return "Disbursement [id=" + id + ", loanApplication=" + loanApplication + ", amount=" + amount
//				+ ", disbursedAt=" + disbursedAt + ", status=" + status + "]";
//	}
//
//    
//}
