package com.loan.loanapplication.model;
 
 
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
 
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="LoanApplicationDetails")
@Data
 
public class LoanApplication {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String applicantName;
    private double annualIncome;
    private double requestedAmount;
 
 
	public int getId() {
		return id;
	}
 
	public void setId(int id) {
		this.id = id;
	}
 
	public String getApplicantName() {
		return applicantName;
	}
 
	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}
 
	public double getAnnualIncome() {
		return annualIncome;
	}
 
	public void setAnnualIncome(double annualIncome) {
		this.annualIncome = annualIncome;
	}
 
	public double getRequestedAmount() {
		return requestedAmount;
	}
 
	public void setRequestedAmount(double requestedAmount) {
		this.requestedAmount = requestedAmount;
	}
 
	@Override
	public String toString() {
		return "LoanApplication [id=" + id + ", applicantName=" + applicantName + ", annualIncome=" + annualIncome
				+ ", requestedAmount=" + requestedAmount + "]";
	}
}