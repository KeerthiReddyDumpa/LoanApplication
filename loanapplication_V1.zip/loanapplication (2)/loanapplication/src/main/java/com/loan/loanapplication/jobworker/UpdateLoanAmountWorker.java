package com.loan.loanapplication.jobworker;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.JobWorker;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class UpdateLoanAmountWorker {

    @JobWorker(type = "update-loan-amount")
    public void handle(final JobClient client, final ActivatedJob job) {
        Map<String, Object> variables = job.getVariablesAsMap();
        Map<String, Object> application = (Map<String, Object>) variables.get("application");
        
        // Get the new loan amount from the message
        Number newLoanAmount = (Number) variables.get("newLoanAmount");
        if (newLoanAmount != null) {
            application.put("requestedAmount", newLoanAmount);
            variables.put("application", application);
        }
        
        client.newCompleteCommand(job.getKey())
              .variables(variables)
              .send()
              .join();
    }
}