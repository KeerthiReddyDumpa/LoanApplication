package com.loan.loanapplication.jobworkertest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import com.loan.loanapplication.jobworker.DisburseLoanWorker;
import com.loan.loanapplication.model.LoanApplication;
import com.loan.loanapplication.repositories.LoanApplicationRepository;

import io.camunda.zeebe.client.api.ZeebeFuture;
import io.camunda.zeebe.client.api.command.CompleteJobCommandStep1;
import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.response.CompleteJobResponse;
import io.camunda.zeebe.client.api.worker.JobClient;

 class DisburseLoanWorkerTest {

    private DisburseLoanWorker worker;
    private LoanApplicationRepository loanApplicationRepository;
    private JobClient jobClient;
    private ActivatedJob job;
    private CompleteJobCommandStep1 commandStep;

    @BeforeEach
    void setUp() {
        loanApplicationRepository = mock(LoanApplicationRepository.class);
        jobClient = mock(JobClient.class);
        job = mock(ActivatedJob.class);
        commandStep = mock(CompleteJobCommandStep1.class);

        worker = new DisburseLoanWorker();
        worker.loanApplicationRepository = loanApplicationRepository;
    }

    @Test
    void testHandle() {
        // Prepare variables
        Map<String, Object> application = new HashMap<>();
        application.put("annualIncome", 100000.0);
        application.put("requestedAmount", 300000.0);
        application.put("applicantName", "Jane Doe");

        Map<String, Object> creditEvaluation = new HashMap<>();
        creditEvaluation.put("approvedAmount", 200000.0);

        Map<String, Object> variables = new HashMap<>();
        variables.put("application", application);
        variables.put("creditEvaluation", creditEvaluation);

        // Setup mocks
        when(job.getVariablesAsMap()).thenReturn(variables);
        when(job.getKey()).thenReturn(123L);
        when(jobClient.newCompleteCommand(123L)).thenReturn(commandStep);
        when(commandStep.variables(anyMap())).thenReturn(commandStep);

        //  Mock ZeebeFuture to avoid NullPointerException
        ZeebeFuture<CompleteJobResponse> mockFuture = mock(ZeebeFuture.class);
        when(commandStep.send()).thenReturn(mockFuture);
        when(mockFuture.join()).thenReturn(null);

        // Act
        worker.handle(jobClient, job);

        // Verify LoanApplication was saved
        ArgumentCaptor<LoanApplication> loanCaptor = ArgumentCaptor.forClass(LoanApplication.class);
        verify(loanApplicationRepository).save(loanCaptor.capture());
        LoanApplication saved = loanCaptor.getValue();

        assertEquals("Jane Doe", saved.getApplicantName());
        assertEquals(100000.0, saved.getAnnualIncome());
        assertEquals(300000.0, saved.getRequestedAmount());

        // Verify that disbursement variables were passed
        ArgumentCaptor<Map<String, Object>> varsCaptor = ArgumentCaptor.forClass(Map.class);
        verify(commandStep).variables(varsCaptor.capture());

        Map<String, Object> sentVars = varsCaptor.getValue();
        assertNotNull(sentVars.get("disbursement"));
        Map<String, Object> disbursement = (Map<String, Object>) sentVars.get("disbursement");

        assertEquals("COMPLETED", disbursement.get("status"));
        assertEquals(200000.0, disbursement.get("amount"));
        assertNotNull(disbursement.get("transactionId"));
        assertNotNull(disbursement.get("disbursedAt"));

        // Verify that the job was completed
        verify(commandStep).send();
        verify(mockFuture).join();
    }
}
