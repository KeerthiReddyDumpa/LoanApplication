package com.loan.loanapplication.jobworkertest;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import com.loan.loanapplication.jobworker.ValidateCoApplicantAgeWorker;

import io.camunda.zeebe.client.api.ZeebeFuture;
import io.camunda.zeebe.client.api.command.CompleteJobCommandStep1;
import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.response.CompleteJobResponse;
import io.camunda.zeebe.client.api.worker.JobClient;

 class ValidateCoApplicantAgeWorkerTest {

    private ValidateCoApplicantAgeWorker worker;
    private JobClient jobClient;
    private ActivatedJob job;
    private CompleteJobCommandStep1 commandStep;

    @BeforeEach
    void setUp() {
        worker = new ValidateCoApplicantAgeWorker();
        jobClient = mock(JobClient.class);
        job = mock(ActivatedJob.class);
        commandStep = mock(CompleteJobCommandStep1.class);
    }

    @Test
    void testCoApplicantAgeValid() {
        // Setup input data
        Map<String, Object> coApplicant = new HashMap<>();
        coApplicant.put("age", 25);

        Map<String, Object> application = new HashMap<>();
        application.put("coApplicant", coApplicant);

        Map<String, Object> variables = new HashMap<>();
        variables.put("application", application);

        // Mocking
        when(job.getVariablesAsMap()).thenReturn(variables);
        when(job.getKey()).thenReturn(1L);
        when(jobClient.newCompleteCommand(1L)).thenReturn(commandStep);
        when(commandStep.variables(anyMap())).thenReturn(commandStep);

        ZeebeFuture<CompleteJobResponse> mockFuture = mock(ZeebeFuture.class);
        when(commandStep.send()).thenReturn(mockFuture);
        when(mockFuture.join()).thenReturn(null);

        // Act
        worker.handle(jobClient, job);

        // Assert
        ArgumentCaptor<Map<String, Object>> varCaptor = ArgumentCaptor.forClass(Map.class);
        verify(commandStep).variables(varCaptor.capture());

        Map<String, Object> sentVars = varCaptor.getValue();
        Map<String, Object> updatedApplication = (Map<String, Object>) sentVars.get("application");

        assertTrue((Boolean) updatedApplication.get("coApplicantAgeValid"));

        verify(commandStep).send();
        verify(mockFuture).join();
    }

    @Test
    void testCoApplicantAgeInvalid() {
        // Setup input data
        Map<String, Object> coApplicant = new HashMap<>();
        coApplicant.put("age", 16);

        Map<String, Object> application = new HashMap<>();
        application.put("coApplicant", coApplicant);

        Map<String, Object> variables = new HashMap<>();
        variables.put("application", application);

        // Mocking
        when(job.getVariablesAsMap()).thenReturn(variables);
        when(job.getKey()).thenReturn(2L);
        when(jobClient.newCompleteCommand(2L)).thenReturn(commandStep);
        when(commandStep.variables(anyMap())).thenReturn(commandStep);

        ZeebeFuture<CompleteJobResponse> mockFuture = mock(ZeebeFuture.class);
        when(commandStep.send()).thenReturn(mockFuture);
        when(mockFuture.join()).thenReturn(null);

        // Act
        worker.handle(jobClient, job);

        // Assert
        ArgumentCaptor<Map<String, Object>> varCaptor = ArgumentCaptor.forClass(Map.class);
        verify(commandStep).variables(varCaptor.capture());

        Map<String, Object> sentVars = varCaptor.getValue();
        Map<String, Object> updatedApplication = (Map<String, Object>) sentVars.get("application");

        assertFalse((Boolean) updatedApplication.get("coApplicantAgeValid"));

        verify(commandStep).send();
        verify(mockFuture).join();
    }
}
