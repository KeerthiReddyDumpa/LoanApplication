package com.loan.loanapplication.jobworkertest;

import com.loan.loanapplication.jobworker.PerformCreditCheckWorker;
import com.loan.loanapplication.model.CreditCheck;
import com.loan.loanapplication.repositories.CreditCheckRepository;
import io.camunda.zeebe.client.api.ZeebeFuture;
import io.camunda.zeebe.client.api.command.CompleteJobCommandStep1;
import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.response.CompleteJobResponse;
import io.camunda.zeebe.client.api.worker.JobClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.Mockito.*;

 class PerformCreditCheckWorkerTest {

    private PerformCreditCheckWorker worker;

    @Mock
    private CreditCheckRepository creditCheckRepository;

    @Mock
    private JobClient jobClient;

    @Mock
    private ActivatedJob job;

    @Mock
    private CompleteJobCommandStep1 completeCommand;

    @Mock
    private ZeebeFuture<CompleteJobResponse> zeebeFuture;

    @BeforeEach
    public void setup() throws Exception {
        MockitoAnnotations.openMocks(this);
        worker = new PerformCreditCheckWorker();

        // Use reflection to inject the mocked repository
        java.lang.reflect.Field repoField = PerformCreditCheckWorker.class.getDeclaredField("creditCheckRepository");
        repoField.setAccessible(true);
        repoField.set(worker, creditCheckRepository);
    }

    @Test
    public void testHandle_PerformCreditCheck() {
        // Arrange input data
        Map<String, Object> application = new HashMap<>();
        application.put("annualIncome", 600000);
        application.put("hasExistingLoans", false);

        Map<String, Object> variables = new HashMap<>();
        variables.put("application", application);

        when(job.getVariablesAsMap()).thenReturn(variables);
        when(job.getKey()).thenReturn(123L);
        when(jobClient.newCompleteCommand(123L)).thenReturn(completeCommand);
        when(completeCommand.variables(anyMap())).thenReturn(completeCommand);
        when(completeCommand.send()).thenReturn(zeebeFuture);
        when(zeebeFuture.join()).thenReturn(null);

        // Act
        worker.handle(jobClient, job);

        // Assert
        assertTrue(variables.containsKey("creditCheck"));
        Map<String, Object> creditCheck = (Map<String, Object>) variables.get("creditCheck");
        assertNotNull(creditCheck.get("creditScore"));
        assertNotNull(creditCheck.get("performedAt"));
        assertTrue(creditCheck.containsKey("risk"));

        verify(creditCheckRepository).save(any(CreditCheck.class));
        verify(completeCommand).send();
        verify(zeebeFuture).join();
    }
}
