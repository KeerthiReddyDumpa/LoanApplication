package com.loan.loanapplication.controllertest;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.loan.loanapplication.controller.LoanApplicationController;

import io.camunda.zeebe.client.ZeebeClient;
import io.camunda.zeebe.client.api.ZeebeFuture;
import io.camunda.zeebe.client.api.command.PublishMessageCommandStep1;
import io.camunda.zeebe.client.api.response.PublishMessageResponse;

@WebMvcTest(LoanApplicationController.class)
 class LoanApplicationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ZeebeClient zeebeClient;

    // Common mocks
    private PublishMessageCommandStep1 publishStep;
    private PublishMessageCommandStep1.PublishMessageCommandStep2 step2;
    private PublishMessageCommandStep1.PublishMessageCommandStep3 step3;
    private ZeebeFuture<PublishMessageResponse> future;

    @BeforeEach
    void setup() {
        publishStep = Mockito.mock(PublishMessageCommandStep1.class);
        step2 = Mockito.mock(PublishMessageCommandStep1.PublishMessageCommandStep2.class);
        step3 = Mockito.mock(PublishMessageCommandStep1.PublishMessageCommandStep3.class);
        future = Mockito.mock(ZeebeFuture.class);

        Mockito.when(zeebeClient.newPublishMessageCommand()).thenReturn(publishStep);
        Mockito.when(publishStep.messageName(any())).thenReturn(step2);
        Mockito.when(step2.correlationKey(any())).thenReturn(step3);
        Mockito.when(step3.variables(any(Map.class))).thenReturn(step3);
        Mockito.when(step3.send()).thenReturn(future);
        Mockito.when(future.join()).thenReturn(null);
    }

    @Test
    void testConfirmApplication() throws Exception {
        mockMvc.perform(post("/api/loan-applications/123/confirm"))
                .andExpect(status().isOk())
                .andExpect(content().string("Application confirmed successfully"));
    }

    @Test
    void testRejectApplication() throws Exception {
        mockMvc.perform(post("/api/loan-applications/456/reject"))
                .andExpect(status().isOk())
                .andExpect(content().string("Application rejected successfully"));
    }

    @Test
    void testCancelApplication() throws Exception {
        // cancel doesn't use variables
        Mockito.when(step2.correlationKey(any())).thenReturn(step3);
        Mockito.when(step3.send()).thenReturn(future);

        mockMvc.perform(post("/api/loan-applications/789/cancel"))
                .andExpect(status().isOk())
                .andExpect(content().string("Application canceled successfully"));
    }
}
