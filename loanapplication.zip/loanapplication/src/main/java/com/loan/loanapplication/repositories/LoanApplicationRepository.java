package com.loan.loanapplication.repositories;


import com.loan.loanapplication.model.LoanApplication;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoanApplicationRepository extends JpaRepository<LoanApplication, Integer> {
}
