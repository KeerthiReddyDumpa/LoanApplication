//package com.loan.loanapplication.model;
//
//
//import java.util.UUID;
//
//import jakarta.persistence.Entity;
//import jakarta.persistence.Id;
//
//@Entity
//public class CoApplicant {
//
//    @Id
//    private String id;
//
//    private String name;
//    private int age;
//    private double annualIncome;
//
//    public CoApplicant() {
//        this.id = UUID.randomUUID().toString();
//    }
//
//	public String getId() {
//		return id;
//	}
//
//	public void setId(String id) {
//		this.id = id;
//	}
//
//	public String getName() {
//		return name;
//	}
//
//	public void setName(String name) {
//		this.name = name;
//	}
//
//	public int getAge() {
//		return age;
//	}
//
//	public void setAge(int age) {
//		this.age = age;
//	}
//
//	public double getAnnualIncome() {
//		return annualIncome;
//	}
//
//	public void setAnnualIncome(double annualIncome) {
//		this.annualIncome = annualIncome;
//	}
//
//	@Override
//	public String toString() {
//		return "CoApplicant [id=" + id + ", name=" + name + ", age=" + age + ", annualIncome=" + annualIncome + "]";
//	}
//
//    
//}
