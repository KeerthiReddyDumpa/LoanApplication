package com.loan.loanapplication.jobworker;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.JobWorker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.loan.loanapplication.model.CreditCheck;
import com.loan.loanapplication.repositories.CreditCheckRepository;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

@Component
public class PerformCreditCheckWorker {
	@Autowired
	
	private CreditCheckRepository creditCheckRepository;
	
    @JobWorker(type = "perform-credit-check")
    public void handle(final JobClient client, final ActivatedJob job) {
        Map<String, Object> variables = job.getVariablesAsMap();
        Map<String, Object> application = (Map<String, Object>) variables.get("application");
        
        if (application.get("id") == null) {
            application.put("id", UUID.randomUUID().toString());
        }
        
        // In a real system, you would call a credit bureau API here
        int creditScore = calculateCreditScore(application);
        CreditCheck creditCheck_Store = new CreditCheck();
        Map<String, Object> creditCheck = new HashMap<>();
        // Change from "score" to "creditScore" to match DMN expectation
        creditCheck.put("creditScore", creditScore);
        creditCheck.put("performedAt", System.currentTimeMillis());
        
        if (creditScore >= 700) {
            creditCheck.put("risk", "LOW");
        } else if (creditScore >= 550) {
            creditCheck.put("risk", "MEDIUM");
        } else {
            creditCheck.put("risk", "HIGH");
        }
        
        variables.put("creditCheck", creditCheck);
        variables.put("application", application);
        
        creditCheck_Store.setId(creditCheck_Store.getId());
        creditCheck_Store.setScore(creditScore);
        creditCheckRepository.save(creditCheck_Store);
 
        client.newCompleteCommand(job.getKey())
            .variables(variables)
            .send()
            .join();
    }
    
    public int calculateCreditScore(Map<String, Object> application) {
        // Same calculation logic as before
        Random random = new Random();
        Number income = (Number) application.get("annualIncome");
        
        // Base score between 500-800
        int baseScore = 500 + random.nextInt(300);
        
        // Adjust based on income (higher income improves score)
        if (income != null) {
            if (income.doubleValue() >= 1000000) {
                baseScore += 100;
            } else if (income.doubleValue() >= 500000) {
                baseScore += 50;
            }
        }
        
        // Adjust based on existing loans
        Boolean hasExistingLoans = (Boolean) application.get("hasExistingLoans");
        if (hasExistingLoans != null && hasExistingLoans) {
            baseScore -= 30;
        }
        
        // Cap at 850 (max credit score)
        return Math.min(850, baseScore);
    }
}