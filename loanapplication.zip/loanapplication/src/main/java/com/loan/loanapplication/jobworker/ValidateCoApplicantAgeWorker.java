package com.loan.loanapplication.jobworker;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.client.api.worker.JobHandler;
import io.camunda.zeebe.spring.client.annotation.JobWorker;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class ValidateCoApplicantAgeWorker {

    @JobWorker(type = "validate-co-applicant-age")
    public void handle(final JobClient client, final ActivatedJob job) {
        Map<String, Object> variables = job.getVariablesAsMap();
        Map<String, Object> application = (Map<String, Object>) variables.get("application");
        Map<String, Object> coApplicant = (Map<String, Object>) application.get("coApplicant");
        
        Integer coApplicantAge = (Integer) coApplicant.get("age");
        boolean isValid = coApplicantAge != null && coApplicantAge >= 18;
        
        application.put("coApplicantAgeValid", isValid);
        variables.put("application", application);
        
        client.newCompleteCommand(job.getKey())
              .variables(variables)
              .send()
              .join();
    }
}