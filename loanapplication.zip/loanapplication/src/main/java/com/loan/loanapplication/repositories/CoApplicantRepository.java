//package com.loan.loanapplication.repositories;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.loan.loanapplication.model.CoApplicant;
//
//public interface CoApplicantRepository extends JpaRepository<CoApplicant, Integer> {
//
//}
