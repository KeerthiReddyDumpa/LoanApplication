package com.loan.loanapplication.model;
 
 
import java.util.Map;
import java.util.UUID;
 
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
 
 
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="CreditCheck")
@Data
public class CreditCheck {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
 
    private int score;
 
	public int getId() {
		return id;
	}
 
	public void setId(int id) {
		this.id = id;
	}
 
	public int getScore() {
		return score;
	}
 
	public void setScore(int score) {
		this.score = score;
	}
 
	@Override
	public String toString() {//", loanApplication=" + loanApplication +
		return "CreditCheck [id=" + id +  ", score=" + score + "]";
	}
 
    
}