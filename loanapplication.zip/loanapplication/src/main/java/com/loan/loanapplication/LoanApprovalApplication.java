package com.loan.loanapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

//@Deployment(resources = {
//    "classpath:Loan_application.bpmn",
//    "classpath:Pre_Screen_Application.dmn",
//    "classpath:Credit_worthiness.dmn"
//})
public class LoanApprovalApplication {
    public static void main(String[] args) {
        SpringApplication.run(LoanApprovalApplication.class, args);
    }
}