package com.loan.loanapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class LoanApprovalApplication {
    public static void main(String[] args) {
        SpringApplication.run(LoanApprovalApplication.class, args);
    }
}