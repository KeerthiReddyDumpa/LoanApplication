package com.loan.loanapplication.jobworker;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.JobWorker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.loan.loanapplication.model.LoanApplication;
import com.loan.loanapplication.repositories.LoanApplicationRepository;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Component
public class DisburseLoanWorker {
	@Autowired
	private LoanApplicationRepository loanApplicationRepository;

    @JobWorker(type = "disburse-loan")
    public void handle(final JobClient client, final ActivatedJob job) {
    	
        Map<String, Object> variables = job.getVariablesAsMap();
        Map<String, Object> application = (Map<String, Object>) variables.get("application");
        Map<String, Object> creditEvaluation = (Map<String, Object>) variables.get("creditEvaluation");
        
        LoanApplication loanApplication = new LoanApplication();

        
        // In a real system, you would integrate with a payment gateway or banking system
        // to transfer the funds to the applicant's account
        
        Map<String, Object> disbursement = new HashMap<>();
        disbursement.put("transactionId", UUID.randomUUID().toString());
        disbursement.put("amount", creditEvaluation.get("approvedAmount"));
        disbursement.put("disbursedAt", LocalDateTime.now().toString());
        disbursement.put("status", "COMPLETED");
        
        variables.put("disbursement", disbursement);

        double annualIncome = Double.parseDouble(application.get("annualIncome").toString());
        System.out.println("annualIncome ==="+annualIncome);
        double requestedAmount = Double.parseDouble(application.get("requestedAmount").toString());
        System.out.println("requestedAmount ==="+requestedAmount);
        System.out.println("name ===="+application.get("applicantName").toString());
        loanApplication.setId(loanApplication.getId());
        loanApplication.setAnnualIncome(annualIncome);
        loanApplication.setApplicantName(application.get("applicantName").toString());
        loanApplication.setRequestedAmount(requestedAmount);
        loanApplicationRepository.save(loanApplication);
        client.newCompleteCommand(job.getKey())
              .variables(variables)
              .send()
              .join();
    }
}