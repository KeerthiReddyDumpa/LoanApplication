package com.loan.loanapplication.controller;

import io.camunda.zeebe.client.ZeebeClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/loan-applications")
public class LoanApplicationController {

    @Autowired
    private ZeebeClient zeebeClient;

    @PostMapping("/{applicationId}/confirm")
    public ResponseEntity<String> confirmApplication(@PathVariable String applicationId) {
        zeebeClient.newPublishMessageCommand()
                .messageName("Customer_Confirmation")
                .correlationKey(applicationId)
                .variables(Map.of("customerResponse", "CONFIRMED"))
                .send()
                .join();
        
        return ResponseEntity.ok("Application confirmed successfully");
    }

    @PostMapping("/{applicationId}/reject")
    public ResponseEntity<String> rejectApplication(@PathVariable String applicationId) {
        zeebeClient.newPublishMessageCommand()
                .messageName("Customer_Confirmation")
                .correlationKey(applicationId)
                .variables(Map.of("customerResponse", "REJECTED"))
                .send()
                .join();
        
        return ResponseEntity.ok("Application rejected successfully");
    }

    @PostMapping("/{applicationId}/cancel")
    public ResponseEntity<String> cancelApplication(@PathVariable String applicationId) {
        zeebeClient.newPublishMessageCommand()
                .messageName("Customer_Cancellation")
                .correlationKey(applicationId)
                .send()
                .join();
        
        return ResponseEntity.ok("Application canceled successfully");
    }
}